# TicTacToe

Run from the root directory of the repository
```
cd TicTacToe
python3 Tic.py
```
To start a 3-row game against the AI.
